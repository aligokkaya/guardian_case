from django.urls import path
from . import views


urlpatterns = [
    path('device-logs/', views.DeviceLogView.as_view()),
    path('stream-logs/', views.StreamLogsView.as_view()),
]