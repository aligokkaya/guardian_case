from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.http import StreamingHttpResponse
import redis
import json
import logging
from datetime import datetime
import time
import threading
from django.views import View
from django.http import HttpResponse

# Redis bağlantısı
redis_client = redis.Redis(host='localhost', port=6379, db=0, decode_responses=True)

class LogManager:
    @staticmethod
    def save_log(email, message, level="INFO", status="info"):
        """Redis'e log kaydet"""
        try:
            # Yeni log
            new_log = {
                "timestamp": datetime.now().isoformat(),
                "level": level,
                "message": message,
                "status": status
            }

            # Mevcut logları al
            current_data = redis_client.get(email)
            if current_data:
                data = json.loads(current_data)
                if data.get('logs'):
                    # Mevcut mesajı güncelle
                    last_log = data['logs'][0]
                    last_log['message'] += f" {message}"
                    last_log['timestamp'] = new_log['timestamp']
                    data['logs'][0] = last_log
                else:
                    data['logs'] = [new_log]
            else:
                data = {'logs': [new_log]}

            # Redis'e kaydet
            redis_client.set(email, json.dumps(data))

            # Stream'e gönder
            stream_data = {
                "email": email,
                "logs": data['logs']
            }
            redis_client.publish('device_logs', json.dumps(stream_data))

            return True
        except Exception as e:
            print(f"Log kaydetme hatası: {e}")
            return False

    @staticmethod
    def get_logs(email):
        """Email'e göre logları getir"""
        try:
            data = redis_client.get(email)
            if data:
                return json.loads(data)
            return {"logs": []}
        except Exception as e:
            print(f"Log getirme hatası: {e}")
            return {"logs": []}

def device_connection_simulator(email, device_name):
    """Cihaz bağlantısını simüle et"""
    try:
        # Bağlantı başlangıç logu
        LogManager.save_log(
            email=email,
            message=f"Connecting to device: {device_name}",
            status="connecting"
        )

        # 2 dakika boyunca veri oku
        start_time = time.time()
        while time.time() - start_time < 120:
            LogManager.save_log(
                email=email,
                message=f"Reading data from {device_name}...",
                status="connected"
            )
            time.sleep(2)

        # Bağlantı bitiş logu
        LogManager.save_log(
            email=email,
            message=f"Connection completed for device: {device_name}",
            status="completed"
        )

    except Exception as e:
        LogManager.save_log(
            email=email,
            message=f"Error: {str(e)}",
            level="ERROR",
            status="error"
        )

class DeviceLogView(APIView):
    def get(self, request):
        """Email'e göre logları getir"""
        email = request.query_params.get('email')
        if not email:
            return Response(
                {"status": "error", "message": "Email gerekli"},
                status=status.HTTP_400_BAD_REQUEST
            )

        logs = LogManager.get_logs(email)
        return Response({
            "status": "success",
            "data": logs
        })

    def post(self, request):
        """Yeni cihaz bağlantısı başlat"""
        email = request.data.get('email')
        device_name = request.data.get('device_name')

        if not email or not device_name:
            return Response(
                {"status": "error", "message": "Email ve device_name gerekli"},
                status=status.HTTP_400_BAD_REQUEST
            )

        # Bağlantıyı arka planda başlat
        thread = threading.Thread(
            target=device_connection_simulator,
            args=(email, device_name)
        )
        thread.daemon = True
        thread.start()

        return Response({
            "status": "success",
            "message": f"Cihaz bağlantısı başlatıldı: {device_name}",
            "data": {
                "email": email,
                "device_name": device_name,
                "timestamp": datetime.now().isoformat()
            }
        }, status=status.HTTP_201_CREATED)

class StreamLogsView(View):
    def get(self, request, *args, **kwargs):
        """Real-time log stream'i başlat"""
        email = request.GET.get('email')

        def event_stream():
            pubsub = redis_client.pubsub()
            pubsub.subscribe('device_logs')

            try:
                for message in pubsub.listen():
                    if message['type'] == 'message':
                        data = json.loads(message['data'])
                        if data.get('email') == email:
                            yield f"data: {json.dumps(data)}\n\n"
                    time.sleep(0.1)  # Küçük bir gecikme ekle
            except GeneratorExit:
                pubsub.unsubscribe('device_logs')
                pubsub.close()

        response = StreamingHttpResponse(
            event_stream(),
            content_type='text/event-stream'
        )
        response['Cache-Control'] = 'no-cache'
        response['X-Accel-Buffering'] = 'no'
        return response 