import { defineStore } from 'pinia'

export const useAuthStore = defineStore('auth', {
  state: () => ({
    user: {
      email: localStorage.getItem('userEmail') || '',
      isAuthenticated: localStorage.getItem('isAuthenticated') === 'true'
    }
  }),
  
  getters: {
    getUserEmail: (state) => state.user.email,
    isAuthenticated: (state) => state.user.isAuthenticated
  },
  
  actions: {
    login(email) {
      console.log('Login with email:', email) // Debug log
      this.user.email = email
      this.user.isAuthenticated = true
      localStorage.setItem('userEmail', email)
      localStorage.setItem('isAuthenticated', 'true')
    },
    
    logout() {
      this.user.email = ''
      this.user.isAuthenticated = false
      localStorage.removeItem('userEmail')
      localStorage.removeItem('isAuthenticated')
    }
  }
}) 