<template>
  <div class="welcome-container">
    <h1>{{ title }}</h1>
    <div class="login-form">
      <div class="input-section">
        <input 
          v-model="email" 
          type="text" 
          placeholder="Kullanıcı adı"
          @keyup.enter="handleLogin"
        >
      </div>
      <div class="input-section">
        <input 
          v-model="password" 
          type="password" 
          placeholder="Şifreniz"
          @keyup.enter="handleLogin"
        >
      </div>
      <button @click="handleLogin">
        Giriş Yap
      </button>
      <p v-if="errorMessage" class="error-message">{{ errorMessage }}</p>
    </div>
  </div>
</template>

<script>
import { useAuthStore } from '@/stores/auth'

export default {
  name: 'LoginView',
  data() {
    return {
      title: 'Giriş Yap',
      email: '',
      password: '',
      errorMessage: ''
    }
  },
  methods: {
    handleLogin() {
      if (!this.email || !this.password) {
        this.errorMessage = 'Lütfen tüm alanları doldurun';
        return;
      }
      
      console.log('Login attempt with:', this.email) // Debug log
      const authStore = useAuthStore()
      authStore.login(this.email)
      console.log('Store state after login:', authStore.$state) // Debug log
      this.$router.push('/dashboard')
    }
  }
}
</script>

<style scoped>
.welcome-container {
  max-width: 400px;
  margin: 40px auto;
  padding: 20px;
  text-align: center;
  background: #252526;
  box-shadow: 0 0 10px rgba(0,0,0,0.3);
  border-radius: 8px;
}

h1 {
  color: #42b883;
  margin-bottom: 30px;
}

.login-form {
  display: flex;
  flex-direction: column;
  gap: 15px;
}

.input-section {
  margin: 5px 0;
}

input {
  padding: 12px;
  border: 1px solid #333;
  border-radius: 4px;
  width: 100%;
  box-sizing: border-box;
  font-size: 14px;
  background: #1e1e1e;
  color: #e0e0e0;
}

input:focus {
  outline: none;
  border-color: #42b883;
  box-shadow: 0 0 0 2px rgba(66, 184, 131, 0.2);
}

button {
  background-color: #42b883;
  color: white;
  border: none;
  padding: 12px 20px;
  border-radius: 4px;
  cursor: pointer;
  width: 100%;
  font-size: 16px;
  transition: background-color 0.3s;
}

button:hover {
  background-color: #3aa876;
}

.error-message {
  color: #ff4444;
  font-size: 14px;
  margin-top: 10px;
}
</style>