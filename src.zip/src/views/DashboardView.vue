<template>
  <div class="dashboard-container">
    <!-- Sidebar -->
    <div class="sidebar">
      <div class="logo-section">
        <h2>Cihaz Log Monitör</h2>
      </div>
      <div class="user-section">
        <div class="user-avatar">{{ userEmail[0].toUpperCase() }}</div>
        <div class="user-info">
          <p class="user-name">{{ userEmail }}</p>
          <span class="user-role">Admin</span>
        </div>
      </div>
      <button @click="handleLogout" class="logout-btn">
        <i class="fas fa-sign-out-alt"></i>
        Çıkış Yap
      </button>
    </div>

    <!-- Ana İçerik -->
    <div class="main-content">
      <!-- Cihaz Sorgu Alanı -->
      <div class="query-section">
        <div class="query-input-area">
          <div class="input-group">
            <label>Cihaz Sorgusu</label>
            <div class="input-with-icon">
              <i class="fas fa-microchip"></i>
              <input 
                v-model="deviceName" 
                type="text"
                placeholder="Cihaz adresini girin..."
                class="query-input"
                @keyup.enter="executeQuery"
              >
            </div>
          </div>
          <button @click="executeQuery" class="execute-btn" :disabled="!deviceName.trim()">
            <i class="fas fa-play"></i>
            Bağlan
          </button>
        </div>
      </div>

      <!-- Log Konsolu -->
      <div class="console-section">
        <div class="console-header">
          <div class="console-title">
            <i class="fas fa-terminal"></i>
            <h3>Log Konsolu</h3>
            <span class="connection-status" :class="{ active: isConnected }">
              <i class="fas fa-circle"></i>
              {{ isConnected ? 'Bağlı' : 'Bağlı Değil' }}
            </span>
          </div>
          <div class="console-actions">
            <button @click="clearLogs" class="action-btn clear-btn">
              <i class="fas fa-trash-alt"></i>
              Temizle
            </button>
            <button class="action-btn" @click="toggleAutoScroll">
              <i class="fas fa-scroll"></i>
              {{ autoScroll ? 'Otomatik Kaydırma: Açık' : 'Otomatik Kaydırma: Kapalı' }}
            </button>
          </div>
        </div>

        <div class="console-content" ref="consoleContent" @scroll="handleScroll">
          <div v-if="!logs.length" class="no-data">
            <i class="fas fa-terminal"></i>
            <p>Henüz log yok</p>
            <span>Bir cihaza bağlanın ve logları görüntüleyin</span>
          </div>
          <template v-else>
            <div v-for="(log, index) in logs" :key="index" class="log-entry">
              <div class="log-header">
                <div class="log-timestamp">
                  <i class="far fa-clock"></i>
                  {{ formatTime(log.timestamp) }}
                </div>
                <div class="log-status" :class="log.status">
                  {{ log.status.toUpperCase() }}
                </div>
              </div>
              <div class="log-message">
                <pre>{{ formatLogMessage(log.message) }}</pre>
              </div>
            </div>
          </template>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { useAuthStore } from '@/stores/auth'
import { mapState } from 'pinia'

export default {
  name: 'DashboardView',
  data() {
    return {
      deviceName: '',
      logs: [],
      isConnected: false,
      autoScroll: true,
      eventSource: null
    }
  },
  computed: {
    ...mapState(useAuthStore, ['getUserEmail']),
    userEmail() {
      const email = this.getUserEmail
      console.log('Computed userEmail:', email)
      return email
    }
  },
  created() {
    const authStore = useAuthStore()
    console.log('Auth store state:', authStore.$state) // Debug log
    
    if (!authStore.isAuthenticated) {
      this.$router.push('/login')
      return
    }

    console.log('Current user email:', this.userEmail) // Debug log
    this.startLogStream()
    this.fetchCurrentLogs()
  },
  beforeUnmount() {
    this.stopLogStream()
  },
  methods: {
    async executeQuery() {
      if (!this.deviceName.trim()) {
        alert('Lütfen bir cihaz adı girin')
        return
      }

      try {
        console.log('Sending request with email:', this.userEmail)
        const response = await fetch('http://localhost:8000/api/device-logs/', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            email: this.userEmail,
            device_name: this.deviceName
          })
        })

        const result = await response.json()
        if (result.status === 'success') {
          this.isConnected = true
          console.log('Bağlantı başlatıldı:', result)
        } else {
          console.error('Bağlantı hatası:', result.message)
        }
      } catch (error) {
        console.error('Bağlantı hatası:', error)
      }
    },

    async fetchCurrentLogs() {
      try {
        const response = await fetch(`http://localhost:8000/api/device-logs/?email=${this.userEmail}`)
        const data = await response.json()
        
        if (data.status === 'success' && data.data && data.data.logs) {
          this.logs = data.data.logs
          if (this.autoScroll) {
            this.$nextTick(() => {
              this.scrollToBottom()
            })
          }
        }
      } catch (error) {
        console.error('Log getirme hatası:', error)
      }
    },

    startLogStream() {
      if (this.eventSource) {
        this.eventSource.close()
      }

      this.eventSource = new EventSource(
        `http://localhost:8000/api/stream-logs/?email=${this.userEmail}`
      )

      this.eventSource.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data)
          if (data.logs) {
            this.logs = data.logs
            if (this.autoScroll) {
              this.$nextTick(() => {
                this.scrollToBottom()
              })
            }
          }
        } catch (error) {
          console.error('Stream verisi işleme hatası:', error)
        }
      }

      this.eventSource.onerror = (error) => {
        console.error('Stream bağlantı hatası:', error)
        this.isConnected = false
        if (this.eventSource) {
          this.eventSource.close()
        }
        // 5 saniye sonra yeniden bağlan
        setTimeout(() => {
          this.startLogStream()
        }, 5000)
      }

      this.eventSource.onopen = () => {
        console.log('Stream bağlantısı açıldı')
        this.isConnected = true
      }
    },

    stopLogStream() {
      if (this.eventSource) {
        this.eventSource.close()
        this.eventSource = null
      }
      this.isConnected = false
    },

    formatLogMessage(message) {
      return message.replace(/\.\.\./g, '...\n')
    },

    formatTime(timestamp) {
      return new Date(timestamp).toLocaleTimeString('tr-TR', {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        fractionalSecondDigits: 3
      })
    },

    scrollToBottom() {
      const element = this.$refs.consoleContent
      if (element) {
        element.scrollTop = element.scrollHeight
      }
    },

    handleScroll() {
      const element = this.$refs.consoleContent
      if (element) {
        const isAtBottom = element.scrollHeight - element.scrollTop === element.clientHeight
        this.autoScroll = isAtBottom
      }
    },

    toggleAutoScroll() {
      this.autoScroll = !this.autoScroll
      if (this.autoScroll) {
        this.scrollToBottom()
      }
    },

    clearLogs() {
      this.logs = []
    },

    handleLogout() {
      this.stopLogStream()
      const authStore = useAuthStore()
      authStore.logout()
      this.$router.push('/login')
    }
  }
}
</script>

<style scoped>
.dashboard-container {
  display: flex;
  min-height: 100vh;
  background-color: #1e1e1e;
  color: #e0e0e0;
}

.sidebar {
  width: 260px;
  background-color: #252526;
  padding: 20px;
  display: flex;
  flex-direction: column;
  border-right: 1px solid #333;
}

.logo-section {
  padding: 20px 0;
  border-bottom: 1px solid #333;
}

.logo-section h2 {
  color: #42b883;
  margin: 0;
}

.user-section {
  display: flex;
  align-items: center;
  padding: 20px 0;
  border-bottom: 1px solid #333;
}

.user-avatar {
  width: 40px;
  height: 40px;
  background-color: #42b883;
  color: white;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: bold;
  margin-right: 12px;
}

.user-info {
  flex: 1;
}

.user-name {
  margin: 0;
  font-weight: 500;
  color: #e0e0e0;
}

.user-role {
  font-size: 0.8em;
  color: #888;
}

.main-content {
  flex: 1;
  padding: 20px;
  overflow-y: auto;
}

.query-section {
  background: #252526;
  padding: 20px;
  border-radius: 8px;
  margin-bottom: 20px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.2);
}

.input-with-icon {
  position: relative;
  display: flex;
  align-items: center;
}

.input-with-icon i {
  position: absolute;
  left: 12px;
  color: #666;
}

.query-input {
  width: 100%;
  padding: 12px 12px 12px 35px;
  background: #1e1e1e;
  border: 1px solid #333;
  border-radius: 6px;
  color: #e0e0e0;
  font-size: 14px;
}

.query-input:focus {
  outline: none;
  border-color: #42b883;
  box-shadow: 0 0 0 2px rgba(66, 184, 131, 0.2);
}

.execute-btn {
  padding: 12px 24px;
  background-color: #42b883;
  color: white;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 8px;
  transition: background-color 0.3s;
}

.execute-btn:hover {
  background-color: #3aa876;
}

.execute-btn:disabled {
  background-color: #2c3e50;
  cursor: not-allowed;
}

.console-section {
  background: #252526;
  border-radius: 8px;
  overflow: hidden;
  box-shadow: 0 2px 4px rgba(0,0,0,0.2);
}

.console-header {
  padding: 15px 20px;
  background: #333;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.console-title {
  display: flex;
  align-items: center;
  gap: 10px;
}

.console-title h3 {
  margin: 0;
  color: #42b883;
}

.connection-status {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 0.9em;
  color: #666;
}

.connection-status.active {
  color: #42b883;
}

.connection-status i {
  font-size: 0.8em;
}

.console-actions {
  display: flex;
  gap: 10px;
}

.action-btn {
  padding: 8px 16px;
  background: #1e1e1e;
  border: 1px solid #333;
  border-radius: 4px;
  color: #e0e0e0;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 6px;
  transition: all 0.3s;
}

.action-btn:hover {
  background: #333;
}

.action-btn.clear-btn {
  color: #ff4444;
}

.console-content {
  height: calc(100vh - 300px);
  overflow-y: auto;
  padding: 20px;
  font-family: 'Fira Code', monospace;
}

.log-entry {
  margin-bottom: 15px;
  background: #1e1e1e;
  border-radius: 6px;
  overflow: hidden;
}

.log-header {
  padding: 8px 12px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  background: #2d2d2d;
  border-bottom: 1px solid #333;
}

.log-timestamp {
  display: flex;
  align-items: center;
  gap: 6px;
  color: #888;
  font-size: 0.9em;
}

.log-status {
  padding: 4px 8px;
  border-radius: 4px;
  font-size: 0.8em;
  font-weight: 500;
}

.log-status.connecting { background-color: #ffa500; color: #1e1e1e; }
.log-status.connected { background-color: #42b883; color: #1e1e1e; }
.log-status.completed { background-color: #2196F3; color: #1e1e1e; }
.log-status.error { background-color: #ff4444; color: #1e1e1e; }

.log-message {
  padding: 12px;
}

.log-message pre {
  margin: 0;
  white-space: pre-wrap;
  word-wrap: break-word;
  color: #e0e0e0;
  font-size: 13px;
  line-height: 1.5;
}

.no-data {
  text-align: center;
  padding: 40px;
  color: #666;
}

.no-data i {
  font-size: 40px;
  margin-bottom: 10px;
  color: #333;
}

@media (max-width: 768px) {
  .dashboard-container {
    flex-direction: column;
  }

  .sidebar {
    width: 100%;
  }

  .console-header {
    flex-direction: column;
    gap: 10px;
  }

  .console-actions {
    width: 100%;
    justify-content: space-between;
  }
}
</style>