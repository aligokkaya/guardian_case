<template>
  <div class="welcome-container">
    <h1>{{ title }}</h1>
    <div class="login-form">
      <div class="input-section">
        <input 
          v-model="email" 
          type="email" 
          placeholder="E-posta adresiniz"
        >
      </div>
      <div class="input-section">
        <input 
          v-model="password" 
          type="password" 
          placeholder="Şifreniz"
        >
      </div>
      <button @click="handleLogin">
        Giriş Yap
      </button>
      <p v-if="errorMessage" class="error-message">{{ errorMessage }}</p>
    </div>
  </div>
</template>

<script>
export default {
  name: 'LoginView',
  data() {
    return {
      title: 'Giriş Yap',
      email: '',
      password: '',
      errorMessage: ''
    }
  },
  methods: {
    handleLogin() {
      if (!this.email || !this.password) {
        this.errorMessage = 'Lütfen tüm alanları doldurun';
        return;
      }
      console.log('Login attempt:', this.email);
      this.errorMessage = '';
    }
  }
}
</script>

<style scoped>
.welcome-container {
  max-width: 400px;
  margin: 40px auto;
  padding: 20px;
  text-align: center;
  box-shadow: 0 0 10px rgba(0,0,0,0.1);
  border-radius: 8px;
}

.login-form {
  display: flex;
  flex-direction: column;
  gap: 15px;
}

.input-section {
  margin: 5px 0;
}

input {
  padding: 12px;
  border: 1px solid #ddd;
  border-radius: 4px;
  width: 100%;
  box-sizing: border-box;
}

button {
  background-color: #42b983;
  color: white;
  border: none;
  padding: 12px 20px;
  border-radius: 4px;
  cursor: pointer;
  width: 100%;
  font-size: 16px;
}

button:hover {
  background-color: #3aa876;
}

.error-message {
  color: #ff4444;
  font-size: 14px;
  margin-top: 10px;
}
</style>